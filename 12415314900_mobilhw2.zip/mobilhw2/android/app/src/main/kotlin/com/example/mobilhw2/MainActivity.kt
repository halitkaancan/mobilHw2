package com.example.mobilhw2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
