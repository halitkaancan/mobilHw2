//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_libphonenumber/FlutterLibphonenumberPlugin.h>)
#import <flutter_libphonenumber/FlutterLibphonenumberPlugin.h>
#else
@import flutter_libphonenumber;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterLibphonenumberPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterLibphonenumberPlugin"]];
}

@end
